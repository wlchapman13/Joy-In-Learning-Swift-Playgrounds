//#-code-completion(identifier, hide, setupLiveView())
//#-hidden-code
import Foundation
//#-end-hidden-code
//#-editable-code Tap to enter code
/**  For this section, make no new variables.  Only a show statement.  */
/** Use a for loop to print a series that goes from 1 to 10.
 
 1
 2
 3
 4
 5
 6
 7
 8
 9
 10
 
 */
for i in 1 ... 10 {
    show(i)
}
show("************************************************")

/** Without using another constant or variable, use the same for-loop you used above to create this output:
 
 twice 1 is 2
 twice 2 is 4
 twice 3 is 6
 twice 4 is 8
 twice 5 is 10
 twice 6 is 12
 twice 7 is 14
 twice 8 is 16
 twice 9 is 18
 twice 10 is 20
 
 */


show("************************************************")

/** Multiples of 5:
 
 Without using another constant or variable, use the same for-loop you used above to create this output:
 
 5 * 1 is 5
 5 * 2 is 10
 5 * 3 is 15
 5 * 4 is 20
 5 * 5 is 25
 5 * 6 is 30
 5 * 7 is 35
 5 * 8 is 40
 5 * 9 is 45
 5 * 10 is 50
 
 */
for i in 1 ... 10 {

}
show("************************************************")

////////////////////////////////////////////////////////

/**  For this section, use the variable i to be the for-loop index and a constant 'j' to hold the result */
/**  Example, multiples of 7 */
for i in 1 ... 10 {
    let j = i * 7
    show("7 * \(i) is \(j)")
}
show("************************************************")

/**  print the first 10 odd numbers.  Your output format should look like this:  */
/*
 
 odd number 1 is 1
 odd number 2 is 3
 odd number 3 is 5
 odd number 4 is 7
 odd number 5 is 9
 odd number 6 is 11
 odd number 7 is 13
 odd number 8 is 15
 odd number 9 is 17
 odd number 10 is 19
 
 */

for i in 1 ... 10 {


}
show("************************************************")

/**  print a sequence of the following numbers  */
/*
 
 i is 1; j is 6
 i is 2; j is 7
 i is 3; j is 8
 i is 4; j is 9
 i is 5; j is 10
 i is 6; j is 11
 i is 7; j is 12
 i is 8; j is 13
 i is 9; j is 14
 i is 10; j is 15
 */

for i in 1 ... 10 {


}
show("************************************************")

/**  print a sequence of the following numbers  */
/*
 
 i is 1; j is 4
 i is 2; j is 7
 i is 3; j is 10
 i is 4; j is 13
 i is 5; j is 16
 i is 6; j is 19
 i is 7; j is 22
 i is 8; j is 25
 i is 9; j is 28
 i is 10; j is 31
 */

for i in 1 ... 10 {


}
show("************************************************")

/**  print a sequence of the following numbers  */
/*
 
 i is 1; j is 15
 i is 2; j is 20
 i is 3; j is 25
 i is 4; j is 30
 i is 5; j is 35
 i is 6; j is 40
 i is 7; j is 45
 i is 8; j is 50
 i is 9; j is 55
 i is 10; j is 60
 
 */

for i in 1 ... 10 {


}
show("************************************************")

/**  print a sequence of the following numbers  */
/*
 
 i is 1; j is 15
 i is 2; j is 20
 i is 3; j is 25
 i is 4; j is 30
 i is 5; j is 35
 i is 6; j is 40
 i is 7; j is 45
 i is 8; j is 50
 i is 9; j is 55
 i is 10; j is 60
 
 */

for i in 1 ... 10 {


}
show("************************************************")

/**  print a sequence of the following numbers  */
/*
 
 i is 1; j is 15
 i is 2; j is 20
 i is 3; j is 25
 i is 4; j is 30
 i is 5; j is 35
 i is 6; j is 40
 i is 7; j is 45
 i is 8; j is 50
 i is 9; j is 55
 i is 10; j is 60
 
 */

for i in 1 ... 10 {


}
show("************************************************")


/**  Do the same algorithm as above, but change the starting and ending i values to be values that are input from the user.
 
 Remember the command to get a value from the user is:
 
 // 2. Ask for a number
 show("What is your favorite number?")
 let number = askForNumber("Number")
 
 */



for i in 1 ... 10 {


}
show("************************************************")

/** Can you reproduce exactly the following output
 
 1st even number is 2
 2nd even number is 4
 3rd even number is 6
 4th even number is 8
 5th even number is 10
 6th even number is 12
 7th even number is 14
 8th even number is 16
 9th even number is 18
 10th even number is 20
 
 */
for i in 1 ... 10 {


}
show("************************************************")

//#-end-editable-code
