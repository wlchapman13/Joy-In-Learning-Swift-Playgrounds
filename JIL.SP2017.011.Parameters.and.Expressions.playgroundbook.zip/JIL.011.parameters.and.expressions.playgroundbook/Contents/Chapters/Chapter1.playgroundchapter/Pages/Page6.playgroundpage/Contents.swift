/*:
 ## Exercise: Show a Formatted Birthday
 
 Write a function that takes three arguments:
 
 1)  a month that is a String
 2)  a day that is an Int
 3)  a year that is an Int
 
 If the values passed into the function are: "June", 13, 1982, then the function should print the following:  
 
 "Your Birthday is June 13, 1982.  Happy Birthday!"
 
 Inside your show statement, use string interpolation to print the message using the format illustrated above.
 
 Your function should be called like this:
 showBirthday(month: "June", day: 13, year: 1982)
 
 When you are finished implementing your function, call it with your birthday.  Also, try calling it with someone else's birthday.
 
 */



//: [Previous](@previous)  |  page 6 of 6
