//number of yellow lemonades sold
let yellow = 8.0 

//pink lemonades sold
let pink = 6.0

//cookies sold
let cookies = 2.0

//total number of lemonade sold
yellow + pink

//revenue from cookies
2.00 * cookies

//revenue from everything
2.00 * cookies + yellow * 1.15 + pink * 1.45
