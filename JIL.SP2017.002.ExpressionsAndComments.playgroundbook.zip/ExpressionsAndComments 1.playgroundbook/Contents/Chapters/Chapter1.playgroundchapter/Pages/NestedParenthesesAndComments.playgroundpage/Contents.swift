//#-hidden-code

/*
 Copyright (C) 2017 William Chapman All Rights Reserved.
 
 Mathematical Expressions - Using a playground like a calculator
*/

//#-end-hidden-code

/*:
 
 ##  Nested Parentheses in Expressions
 
 In the expression below, the innermost parentheses will be evaluated first (2 + 3) before the outermost parentheses are evaluated ((2 + 3) * 2).  Having one expression (in parentheses) embedded within another expressions in parentheses is called **nested parentheses**.  We say, "one expression is nested within another expression."  Execute (run) the code to see that the result is 10 + 3, or 13.
 
*/

((2 + 3) * 2) + 3

//  Inner parentheses are evaluated first.  Outer parentheses are evaluated second.  Math expressions outside parentheses are evaluated last - multiplication and division first, addition and subtraction last.

14 - ((5 + 2) * 2)

/*:  
 
 Notice the text in the code above with the "//" in front of it?  These are called comments.  **Comments** are messages to ourselves or other people inserted into our Swift code.  Commments are **not** executed by the computer.
 
 Add your own comment below and add a mathematical expression that uses parentheses.  Execute the code to see if the computer gets the correct answer.
 
*/

//

/*:  
 
 Why is the following expression not evaluated?
 
*/
 
 
 //  10 - (5 + 2)
 

/*:  
 
 Can you change the code below so that the expression is evaluated?
 
*/
 
 //  16 + (8 / 2)


/*:   If you are interested in more advanced mathematical operators, visit the final page in this chapter:
 
 [**When finished, proceed to next page.**](@next)
 
*/


