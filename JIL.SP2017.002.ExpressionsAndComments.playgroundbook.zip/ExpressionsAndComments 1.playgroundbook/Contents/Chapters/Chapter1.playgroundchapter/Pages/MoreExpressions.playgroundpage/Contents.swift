//#-hidden-code

/*
 Copyright (C) 2017 William Chapman All Rights Reserved.
 
 Mathematical Expressions - Using a playground like a calculator
*/

//#-end-hidden-code

/*:
 
 ##  More Math Expressions
 
 Of course, you can use any math operators in your expressions.  Here are some with multiplication and division:
 
 */

6 * 2

24 / 3

/*:  
 
 Press the red "Run this code" button in the lower right corner to see the results of the calculation.  Tap the grey boxes to see the results of the expressions.  Did the computer get them correct?
 

 ##  Parentheses
 
 Parentheses around a nested expression will cause that expression to be evaluated first.  Predict the value of each of these before running the playground again.  Remember, do what is in the parentheses first!
 
 */

(6 + 4) / 2

4 + (3 * 2)

/*:
 
 ##  Multiple uses of the **+** expressions
 
 Try running this expressions and watch what the **+** operator does with a series of words
 
 */

"Four score" + " and " + "seven years ago..."

/*:  
 
 Enter some of your own expressions below.  Try some with, and without parentheses.  Run the playground and check the results to see if the computer got it correct.
 
 [**When finished, proceed to next page.**](@next)
 
 */
