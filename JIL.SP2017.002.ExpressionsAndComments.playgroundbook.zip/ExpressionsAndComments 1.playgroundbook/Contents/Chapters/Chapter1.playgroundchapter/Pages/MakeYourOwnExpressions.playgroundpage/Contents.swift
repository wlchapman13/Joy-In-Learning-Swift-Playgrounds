//#-hidden-code

/*
 Copyright (C) 2017 William Chapman All Rights Reserved.
 
 Mathematical Expressions - Using a playground like a calculator
 */

//#-end-hidden-code

/*:
 
 ##  Math Expressions
 
Math expressions can be as simple, or as complex as you want.
 
Let's try two here:
 
 */

2 + 2

6 + 3 - 1 + 2 + 7 + 5 - 6 + 3 + 2 + 9 - 5 - 2 + 5 - 1 + 4


/*:  
 
 Press the red "Run this code" button in the lower right corner to see the results of the calculation.  Tap the grey boxes to see the results of the expressions.  Did the computer get them correct?
 
 Write your own expressions below to try it out for yourself.  Make one simple and one more complex:
 
 
 */

/*:  
 
 Press the red "Run this code" button in the lower right corner to see the results of the calculation.  Tap the grey boxes to see the results of the expressions.  Did the computer get them correct?
 
 [**When finished, proceed to next page.**](@next)

 */

