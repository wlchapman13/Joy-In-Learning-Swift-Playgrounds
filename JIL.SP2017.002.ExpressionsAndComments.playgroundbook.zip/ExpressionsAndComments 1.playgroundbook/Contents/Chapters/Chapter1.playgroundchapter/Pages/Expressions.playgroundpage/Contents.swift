//#-hidden-code

/*
 Copyright (C) 2017 William Chapman All Rights Reserved.
 
 Mathematical Expressions - Using a playground like a calculator
*/

//#-end-hidden-code

/*:
 
 ##  Math Expressions
 
 This is a playground.  It uses the programming language Swift.
 
 One of the most simple uses of a playground is as a fancy calculator.  You can write mathematical expressions in your playground and have the computer calculate the results.
 
 Let's try one here:
 
 */

2 + 3

7 - 1

/*:  
 
 Press the red "Run this code" button in the lower right corner to see the results of the calculation.
 
 When you run the playground, the results will be hidden in a grey boxes along the right side of the playground.  Tap the grey boxes to see the results of the expressions.  Did the computer get them correct?
 
 **[**When finished, tap this line to proceed to next page.**](@next)**
 
 */
