//#-hidden-code

/*
 Copyright (C) 2017 William Chapman All Rights Reserved.
 
 Mathematical Expressions - Using a playground like a calculator
*/

import Foundation

//#-end-hidden-code

/*:
 
 ##  Square Root
 
 To determine the square root of a value, use the sqrt() function, like this:
 
*/

sqrt(36)

/*:
 
 ##  Power Function
 
 To determine the value of x raised to a power y, use the pow(x, y) function, like this:
 
 */


// two to the third power:
pow(2.0, 3.0)

// eight to the second power (8 squared):
pow(8.0, 2.0)

/*:
 
 ##  Absolute Value
 
 To determine the absolute value of a value, use the abs() function like this:
 
 */

abs(14)

abs(-14)

