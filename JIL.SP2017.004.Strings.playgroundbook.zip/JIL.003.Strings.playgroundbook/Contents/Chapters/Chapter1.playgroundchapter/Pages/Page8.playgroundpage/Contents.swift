//: ## Viewing Playground Results
//: What if you define a long string in a playground? Run this code.  You’ll notice that the longer string may be cut off at the end in the results sidebar. 👉
//:
let spelledOutNumber = "six"
let meal = "breakfast"
let aliceQuotation = "Why, sometimes I’ve believed as many as \(spelledOutNumber) impossible things before \(meal)!"
//: Tap the results sidebar (the grey square with "abc" in it). When you do, the result "Why, sometimes I’ve believed..." will be highlighted and a message "Add viewer" will appear:
//:
//: ![Sidebard Controls](results.sidebar.image.png)

//:
//: Tap the "Add viewer" control. The result of that line of code is added directly below the code. You can click this control again anytime to remove the result.
//:
//: For now, leave the result of the long string showing. Change the values of the spelled out number and the meal. Notice how the result changes inline in the playground.
//:
//: On the next page, take these strings even further.
//:
//:[Previous](@previous)  |  page 8 of 16  |  [Next: More Than Strings](@next)
