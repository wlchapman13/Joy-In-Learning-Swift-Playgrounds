//: ## Typing Names and Autocompletion
//: Swift Playgrounds keeps track of all the names you’ve defined. So when you start typing, you’ll see a menu of suggested names (the names it knows about). This is called _autocompletion_.
//:
//: Autocompletion helps you write code more quickly and with fewer typing mistakes. The more you type, the more the autocompletion menu narrows down to what you’re looking for.
//:
//: Whenever the autocompletion menu appears you can:
//: - Keep typing to narrow down the list.
//: - Swipe left and right to move through the list.
//: - Tap the correct suggestion to have Swift Playgrounds fill in the selected name.
//:
//: In the list, you’ll see names that you didn’t define. It's perfectly fine to ignore those names.
//:
//: Using this feature saves a lot of time typing.  But more importantly, it encourages us to use _descriptive names_ for our constants.  These descriptive names are the key to understanding someone else's program, or even your own if you leave it for a while and come back to work on it at a later time.
//:
//: A well-written Swift program, complete with descriptive names, will read a lot like a well-written book.
//:
//: As part of the experiment on the next page you’ll type in some names and see autocompletion in action.
//:
//:[Previous](@previous)  |  page 3 of 12  |  [Next: Identifiers](@next)
