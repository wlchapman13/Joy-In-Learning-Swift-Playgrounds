/*:
 ## The Argument Without a Name
 
 Look at the show function:\
 `show("Hello")`
 
 When you call it, it has no argument label. That’s not a problem because `show("Hello")` makes sense on its own.
 
 Besides, it’s awkward to read `show(thingToPrint: "Hello")` and `thingToPrint` doesn't add any information.
 
 The parameter in `show` does not have an argument label. To declare a parameter without an argument label, you use the underscore `_` where the argument label would go. In Swift, the underscore means "I don't care about this item because I'm not going to use it".
 
 For example:
 */
func printHelloTo(_ name: String) {
    show("Hello " + name)
}
printHelloTo("Maya")
printHelloTo("Hiro")
//: - experiment: Call the `printHelloTo` function a few more times. Notice that the autocompletion popup shows the parameter name, not the argument label.



//: Now it’s time to summarize what you’ve learned.
//:
//: [Previous](@previous)  |  page 7 of 12  |  [Next: Wrapup](@next)
