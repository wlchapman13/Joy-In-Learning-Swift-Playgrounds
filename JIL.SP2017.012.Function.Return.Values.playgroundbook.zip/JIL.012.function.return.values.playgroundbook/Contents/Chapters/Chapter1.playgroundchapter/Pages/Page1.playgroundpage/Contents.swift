/*:
 ## Getting Values Back
 
 In addition to using values that you’ve passed in, functions can do their work and hand you back a value as a result.
 
 Passing a value back when a function is finished is called _returning_ a value. To declare a function that returns a value, you have to add two things to your code.
 
 After your list of parameters, add a text arrow `->` and the type of value to be returned. For example:
 `-> String` means the function returns a `String`.
 
 Then you have to end the body of the function with a return statement that gives that type of value back.
 
 Here’s a function that takes some numbers, does some work, and returns a string:
 */
func averageOf(num1: Int, num2: Int) -> String {
    let sum = num1 + num2
    let average = sum / 2
    
    return "The average of \(num1) and \(num2) is \(average)!"
}

averageOf(num1: 6, num2: 10)

//: > Your function can have multiple parameters, but it can only return **one** value.
//:
//: The value that a function returns is just like any other. It can be assigned to a variable or a constant and can be used for other work. Variables and constants can also be used as the arguments:
let firstGolfScore = 90
let secondGolfScore = 86
let golfMessage = averageOf(num1: firstGolfScore, num2: secondGolfScore)
show("Jennifer Golf Statistics! \(golfMessage)" )


//: Try making your own function that returns a value.
//:
//: [Previous](@previous)  |  page 1 of 12  |  [Next: Giving Values Back](@next)
