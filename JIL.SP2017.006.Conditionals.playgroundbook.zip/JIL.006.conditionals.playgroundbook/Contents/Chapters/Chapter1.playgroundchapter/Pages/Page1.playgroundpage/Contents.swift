/*:
Can you predict what this for-loop with print?
  */
 for i in 1 ... 10 {
    show("\(i)st even number is: \(2*i)")
 }

/*:
 Run the program to see what it will print.  Is this what you expected?  Is this correct?
 Can you think of how you might make it correct?
 
 Sometimes as programmers, we need to execute different code depending on the values of a certain variable.  Or we may need to execute different code depending on some other condition in our program. 
 
 In this chapter, we will learn how to change the flow of our program depending on different conditions.
 
 page 1 of 12  |  [Next: Making Decisions](@next)
 */
